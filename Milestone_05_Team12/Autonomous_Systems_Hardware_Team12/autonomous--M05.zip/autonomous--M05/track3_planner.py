# Claude
# """
# APF City Track Planner — Team 12  (HARDWARE VERSION)
# =====================================================
# Implements an Artificial Potential Field planner for a rectangular loop track.

# Track geometry (from SDF, all in metres): NOTE
#   Outer walls:  x ∈ [0, 5],  y ∈ [-2, 2]  (with r≈0.5 m rounded corners)
#   Inner walls:  x ∈ [0.75, 4.25],  y ∈ [-1.25, 1.25]  (with r≈0.25 m corners)
#   Centreline:   x ∈ [0.375, 4.625], y ∈ [-1.625, 1.625]

# ─────────────────────────────────────────────────────────────────────────────
# HARDWARE COORDINATE FRAME NOTE
# ─────────────────────────────────────────────────────────────────────────────
# On hardware the odometry is computed from IMU + encoder dead-reckoning:

#     vx = vd * cos(θ)          vy = vd * sin(θ)
#     x_curr = x_prev + r * vx  y_curr = y_prev + r * vy

# When θ = 0 the car moves along the **physical +x axis**, so:
#   • Straight segments along the track's LONG axis  → θ = 0  or  θ = π
#   • Straight segments along the track's SHORT axis → θ = π/2  or  θ = -π/2

# In Gazebo the world is set up so the long axis is also x, but the planner
# originally described the first motion as "vertical (y-axis in Gazebo)", which
# means in the original planner the car was assumed to start heading north
# (θ = π/2) and x stayed constant while y changed.

# To make the planner consistent with hardware dead-reckoning the waypoint
# coordinates and all heading references are **rotated -90°** relative to the
# Gazebo SDF frame:

#     hw_x =  gz_y      (Gazebo y  → hardware x)
#     hw_y = -gz_x      (Gazebo x  → hardware -y)

# Under this transform:
#   • Top straight (Gazebo: y = +1.625, x varies)  → hw: x = +1.625, y varies
#     heading: Gazebo 0 (east) → hardware -π/2 (south in hw frame)
#     ... but the car physically drives along its nose (θ = 0) on the top straight,
#     so the transform is applied as a pure re-labelling and the heading table is
#     rebuilt to match.

# In practice the simplest and safest fix is:

#   1. Re-express every waypoint as  (hw_x, hw_y) = (gz_y, -gz_x)
#   2. Rebuild STRAIGHT_HEADINGS so θ = 0 corresponds to the top straight
#      (long axis, positive direction).

# The result is that when the car drives the top straight it publishes θ = 0
# and the dead-reckoning x position advances while y stays constant — exactly
# what the hardware equations produce.

# ─────────────────────────────────────────────────────────────────────────────

# Controller selection strategy
# -------------------------------
#   STRAIGHT segments  →  Speed controller  (/desired_velocity)
#   CORNER  segments   →  Waypoint P2P controller  (/goal_point)

# Both heading and goal are always published so the Stanley lateral controller
# always has something to track.

# Published topics
# ----------------
#   /goal_point        (geometry_msgs/Point)   – next waypoint
#   /desired_velocity  (std_msgs/Float64)      – target speed for speed ctrl
#   /desired_heading   (std_msgs/Float64)      – path tangent angle (radians)

# Subscribed topics
# -----------------
#   /odom              (nav_msgs/Odometry)     – robot pose & velocity
# """

# import math
# import rclpy
# from rclpy.node import Node
# from std_msgs.msg import Float64
# from nav_msgs.msg import Odometry
# from geometry_msgs.msg import Point


# # ─────────────────────────────────────────────────────────────────────────────
# # Coordinate transform helper
# # Converts a Gazebo (gz_x, gz_y) point to hardware frame (hw_x, hw_y).
# #   hw_x =  gz_y
# #   hw_y = -gz_x
# # ─────────────────────────────────────────────────────────────────────────────

# def gz_to_hw(gz_x, gz_y):
#     """Rotate Gazebo world frame −90° to match hardware dead-reckoning frame."""
#     return gz_y, -gz_x


# # ─────────────────────────────────────────────────────────────────────────────
# # Gazebo centreline bounds (kept for reference / documentation)
# # ─────────────────────────────────────────────────────────────────────────────
# #   GZ_CX_LEFT  = 0.375,  GZ_CX_RIGHT = 4.625   (long axis)
# #   GZ_CY_TOP   = 1.625,  GZ_CY_BOTTOM = -1.625  (short axis)

# # Hardware centreline bounds after -90° rotation
# #   hw_x = gz_y  →  HW_CX_BOTTOM = -1.625, HW_CX_TOP   =  1.625
# #   hw_y = -gz_x →  HW_CY_LEFT   = -4.625, HW_CY_RIGHT = -0.375

# GZ_CX_LEFT   = 0.375
# GZ_CX_RIGHT  = 4.625
# GZ_CY_TOP    = 1.625
# GZ_CY_BOTTOM = -1.625

# # Hardware-frame equivalents (used for waypoint definitions below)
# HW_X_TOP    =  GZ_CY_TOP      #  1.625  (positive x side of track)
# HW_X_BOTTOM =  GZ_CY_BOTTOM   # -1.625  (negative x side of track)
# HW_Y_LEFT   = -GZ_CX_RIGHT    # -4.625  (left end in hardware y)
# HW_Y_RIGHT  = -GZ_CX_LEFT     # -0.375  (right end in hardware y)

# # ─────────────────────────────────────────────────────────────────────────────
# # Track centreline waypoints (counter-clockwise, hardware frame)
# #
# # Gazebo CCW order: TL → TR → BR → BL → TL …
# #
# # After -90° rotation the corners map to:
# #   Gazebo TL (0.375,  1.625) → HW ( 1.625, -0.375)  = hardware Top-Right  (HTR)
# #   Gazebo TR (4.625,  1.625) → HW ( 1.625, -4.625)  = hardware Top-Left   (HTL)
# #   Gazebo BR (4.625, -1.625) → HW (-1.625, -4.625)  = hardware Bot-Left   (HBL)
# #   Gazebo BL (0.375, -1.625) → HW (-1.625, -0.375)  = hardware Bot-Right  (HBR)
# #
# # CCW in Gazebo corresponds to CCW in the hardware frame as well because the
# # transform is a pure rotation (orientation-preserving).
# #
# # Format: (hw_x, hw_y, segment_type, v_straight, v_corner)
# # ─────────────────────────────────────────────────────────────────────────────

# WAYPOINTS = [
#     # hw_x,        hw_y,         type      v_straight  v_corner
#     (HW_X_TOP,    HW_Y_RIGHT,   'corner',  0.0,        0.4),  # 0  HTR  (was Gazebo TL)
#     (HW_X_TOP,    HW_Y_LEFT,    'corner',  0.0,        0.4),  # 1  HTL  (was Gazebo TR)
#     (HW_X_BOTTOM, HW_Y_LEFT,    'corner',  0.0,        0.4),  # 2  HBL  (was Gazebo BR)
#     (HW_X_BOTTOM, HW_Y_RIGHT,   'corner',  0.0,        0.4),  # 3  HBR  (was Gazebo BL)
# ]

# # ─────────────────────────────────────────────────────────────────────────────
# # Straight headings in hardware frame
# #
# # Segment 0→1: top straight, x = +1.625 const, y decreases (HW_Y_RIGHT → HW_Y_LEFT)
# #   → moving in –y direction  → θ = -π/2
# # Segment 1→2: right straight (hw), y = -4.625 const, x decreases (+1.625 → -1.625)
# #   → moving in –x direction  → θ = π
# # Segment 2→3: bottom straight, x = -1.625 const, y increases (HW_Y_LEFT → HW_Y_RIGHT)
# #   → moving in +y direction  → θ = π/2
# # Segment 3→0: left straight (hw), y = -0.375 const, x increases (-1.625 → +1.625)
# #   → moving in +x direction  → θ = 0
# #
# # NOTE: If the car is physically placed so that it starts on the top straight
# # heading in the +y direction (θ = 0 on hardware), then the physical +y axis
# # aligns with the track's long axis and the heading table below must be shifted
# # accordingly.  Adjust START_HEADING_OFFSET below to rotate all headings if
# # the car's initial θ = 0 direction differs from the above assumptions.
# # ─────────────────────────────────────────────────────────────────────────────

# # Set to 0.0 if the car's θ=0 (IMU zero) points in the hardware +x direction
# # (i.e. across the short axis of the track).
# # Set to π/2 if θ=0 points along the long axis of the track.
# START_HEADING_OFFSET = 0.0   # radians — tune per physical setup

# def _h(angle):
#     """Wrap a heading to [-π, π] after applying the start offset."""
#     a = angle + START_HEADING_OFFSET
#     return math.atan2(math.sin(a), math.cos(a))


# STRAIGHT_HEADINGS = {
#     0: _h(-math.pi / 2),   # top straight:    –y direction
#     1: _h(math.pi),        # right straight:  –x direction
#     2: _h(math.pi / 2),    # bottom straight: +y direction
#     3: _h(0.0),            # left straight:   +x direction
# }

# # ─────────────────────────────────────────────────────────────────────────────
# # Speed / distance settings (unchanged from simulation version)
# # ─────────────────────────────────────────────────────────────────────────────

# STRAIGHT_SPEED      = 1.2   # m/s – published on /desired_velocity
# CORNER_SPEED        = 0.4   # m/s – used by P2P controller

# CORNER_REACH_DIST   = 0.30  # m
# STRAIGHT_REACH_DIST = 0.35  # m


# # ─────────────────────────────────────────────────────────────────────────────
# # Planner node
# # ─────────────────────────────────────────────────────────────────────────────

# class Hardware_track3_Planner(Node):

#     def __init__(self):
#         super().__init__('Hardware_track3_Planner')

#         # ── Publishers ───────────────────────────────────────────────────
#         self.pub_goal    = self.create_publisher(Point,   '/goal_point',       10)
#         self.pub_vel     = self.create_publisher(Float64, '/desired_velocity',  10)
#         self.pub_heading = self.create_publisher(Float64, '/desired_heading',   10)

#         # ── Subscriber ───────────────────────────────────────────────────
#         self.create_subscription(Odometry, '/odom', self.odom_cb, 10)

#         # ── State ────────────────────────────────────────────────────────
#         self.x     = 0.0
#         self.y     = 0.0
#         self.speed = 0.0

#         # Start targeting the first corner waypoint
#         self.wp_idx      = 0     # index into WAYPOINTS[]
#         self.on_straight = False  # True while driving a straight segment

#         # ── Timer (10 Hz) ────────────────────────────────────────────────
#         self.timer = self.create_timer(0.1, self.plan_cb)
#         self.get_logger().info(
#             'APF Planner (HARDWARE) started — driving counter-clockwise. '
#             f'START_HEADING_OFFSET = {math.degrees(START_HEADING_OFFSET):.1f}°'
#         )

#     # ── Odometry ─────────────────────────────────────────────────────────────

#     def odom_cb(self, msg: Odometry):
#         """
#         On hardware the odometry node publishes positions in the hardware frame
#         (dead-reckoned from IMU + encoder).  No transform needed here.
#         """
#         self.x     = msg.pose.pose.position.x
#         self.y     = msg.pose.pose.position.y
#         self.speed = msg.twist.twist.linear.x

#     # ── Main planning loop ───────────────────────────────────────────────────

#     def plan_cb(self):
#         wx, wy, wtype, _, _ = WAYPOINTS[self.wp_idx]
#         dist = math.hypot(wx - self.x, wy - self.y)

#         if not self.on_straight:
#             self._publish_corner_mode(wx, wy, dist)
#         else:
#             self._publish_straight_mode(dist)

#     # ── Corner mode ──────────────────────────────────────────────────────────

#     def _publish_corner_mode(self, wx, wy, dist):
#         """
#         Send goal_point to the P2P waypoint controller.
#         Publish a slow desired_velocity so the speed controller doesn't race.
#         Publish the heading towards the corner goal.
#         """
#         heading = math.atan2(wy - self.y, wx - self.x)

#         self._pub_goal(wx, wy)
#         self._pub_heading(heading)
#         self._pub_velocity(CORNER_SPEED)

#         self.get_logger().debug(
#             f'[CORNER→WP{self.wp_idx}] '
#             f'goal=({wx:.3f},{wy:.3f}) '
#             f'dist={dist:.2f}  heading={math.degrees(heading):.1f}°'
#         )

#         if dist < CORNER_REACH_DIST:
#             self.get_logger().info(
#                 f'Corner WP{self.wp_idx} reached — switching to straight.'
#             )
#             self.on_straight = True

#     # ── Straight mode ────────────────────────────────────────────────────────

#     def _publish_straight_mode(self, dist_to_next_corner):
#         """
#         Use the speed controller for longitudinal motion.
#         Publish the straight's ideal heading (hardware frame).
#         Goal point is the next corner to keep the lateral controller informed.
#         """
#         next_idx = (self.wp_idx + 1) % len(WAYPOINTS)
#         nx, ny, _, _, _ = WAYPOINTS[next_idx]

#         heading = STRAIGHT_HEADINGS[self.wp_idx]

#         self._pub_goal(nx, ny)
#         self._pub_heading(heading)
#         self._pub_velocity(STRAIGHT_SPEED)

#         dist_next = math.hypot(nx - self.x, ny - self.y)

#         self.get_logger().debug(
#             f'[STRAIGHT→WP{next_idx}] '
#             f'goal=({nx:.3f},{ny:.3f}) '
#             f'dist={dist_next:.2f}  v={STRAIGHT_SPEED}  '
#             f'heading={math.degrees(heading):.1f}°'
#         )

#         if dist_next < CORNER_REACH_DIST + 0.20:
#             self.get_logger().info(
#                 f'Approaching corner WP{next_idx} — switching to corner mode.'
#             )
#             self.wp_idx      = next_idx
#             self.on_straight = False

#     # ── Helpers ──────────────────────────────────────────────────────────────

#     def _pub_goal(self, x, y):
#         msg = Point()
#         msg.x = float(x)
#         msg.y = float(y)
#         msg.z = 0.0
#         self.pub_goal.publish(msg)

#     def _pub_heading(self, angle):
#         msg = Float64()
#         msg.data = float(angle)
#         self.pub_heading.publish(msg)

#     def _pub_velocity(self, v):
#         msg = Float64()
#         msg.data = float(v)
#         self.pub_vel.publish(msg)


# # ─────────────────────────────────────────────────────────────────────────────

# def main(args=None):
#     rclpy.init(args=args)
#     node = Hardware_track3_Planner()
#     try:
#         rclpy.spin(node)
#     except KeyboardInterrupt:
#         pass
#     finally:
#         node.destroy_node()
#         if rclpy.ok():
#             rclpy.shutdown()


# if __name__ == '__main__':
#     main()

# ## GEMINI TRIAL 1
# """
# APF City Track Planner — Team 12 (Hardware Adjusted)
# ==================================================
# Adjusted to align Gazebo track geometry with hardware IMU/Encoder integration.
# The track is rotated 90 degrees so the long straights align with the hardware Y-axis.
# """

# import math
# import rclpy
# from rclpy.node import Node
# from std_msgs.msg import Float64
# from nav_msgs.msg import Odometry
# from geometry_msgs.msg import Point

# # ─────────────────────────────────────────────────────────────────────────────
# # Track centreline waypoints (ROTATED FOR HARDWARE)
# # Original Gazebo: x in [0.375, 4.625], y in [-1.625, 1.625]
# # Hardware Mapping: 
# # New X = Original Y
# # New Y = Original X
# # ─────────────────────────────────────────────────────────────────────────────

# # Rotated Bounds
# CX_MIN = -1.625
# CX_MAX = 1.625
# CY_MIN = 0.375
# CY_MAX = 4.625

# # Counter-clockwise sequence adjusted for rotated frame
# WAYPOINTS = [
#     # (x,       y,      type,      v_straight, v_corner)
#     (CX_MIN, CY_MAX, 'corner', 0.0, 0.4),  # 0: Was Top-Left, now "Left-Top"
#     (CX_MAX, CY_MAX, 'corner', 0.0, 0.4),  # 1: Was Top-Right, now "Right-Top"
#     (CX_MAX, CY_MIN, 'corner', 0.0, 0.4),  # 2: Was Bot-Right, now "Right-Bottom"
#     (CX_MIN, CY_MIN, 'corner', 0.0, 0.4),  # 3: Was Bot-Left, now "Left-Bottom"
# ]

# # Headings adjusted for the new frame
# # 0 rad = +X (Right), pi/2 = +Y (Up), -pi/2 = -Y (Down), pi = -X (Left)
# STRAIGHT_HEADINGS = {
#     0: 0.0,           # Move Right (from Left-Top to Right-Top)
#     1: -math.pi / 2,  # Move Down  (from Right-Top to Right-Bottom)
#     2: math.pi,       # Move Left  (from Right-Bottom to Left-Bottom)
#     3: math.pi / 2,   # Move Up    (from Left-Bottom to Left-Top)
# }

# # Speed settings and thresholds
# STRAIGHT_SPEED   = 1.2   
# CORNER_SPEED     = 0.4   
# CORNER_REACH_DIST   = 0.30   
# STRAIGHT_REACH_DIST = 0.35   

# class APFPlannerTrack(Node):
#     def __init__(self):
#         super().__init__('apf_planner_track')

#         self.pub_goal    = self.create_publisher(Point,   '/goal_point',       10)
#         self.pub_vel     = self.create_publisher(Float64, '/desired_velocity',  10)
#         self.pub_heading = self.create_publisher(Float64, '/desired_heading',   10)
#         self.create_subscription(Odometry, '/odom', self.odom_cb, 10)

#         self.x, self.y, self.speed = 0.0, 0.0, 0.0
#         self.wp_idx = 0   
#         self.on_straight = False  

#         self.timer = self.create_timer(0.1, self.plan_cb)
#         self.get_logger().info('Hardware-Adjusted APF Planner started.')

#     def odom_cb(self, msg: Odometry):
#         self.x = msg.pose.pose.position.x
#         self.y = msg.pose.pose.position.y
#         self.speed = msg.twist.twist.linear.x

#     def plan_cb(self):
#         wx, wy, _, _, _ = WAYPOINTS[self.wp_idx]
#         dist = math.hypot(wx - self.x, wy - self.y)

#         if not self.on_straight:
#             self._publish_corner_mode(wx, wy, dist)
#         else:
#             self._publish_straight_mode(dist)

#     def _publish_corner_mode(self, wx, wy, dist):
#         heading = math.atan2(wy - self.y, wx - self.x)
#         self._pub_goal(wx, wy)
#         self._pub_heading(heading)
#         self._pub_velocity(CORNER_SPEED)

#         if dist < CORNER_REACH_DIST:
#             self.on_straight = True

#     def _publish_straight_mode(self, dist_to_next_corner):
#         next_idx = (self.wp_idx + 1) % len(WAYPOINTS)
#         nx, ny, _, _, _ = WAYPOINTS[next_idx]
#         heading = STRAIGHT_HEADINGS[self.wp_idx]

#         self._pub_goal(nx, ny)
#         self._pub_heading(heading)
#         self._pub_velocity(STRAIGHT_SPEED)

#         dist_next = math.hypot(nx - self.x, ny - self.y)
#         if dist_next < CORNER_REACH_DIST + 0.20:
#             self.wp_idx = next_idx
#             self.on_straight = False

#     def _pub_goal(self, x, y):
#         msg = Point()
#         msg.x, msg.y, msg.z = float(x), float(y), 0.0
#         self.pub_goal.publish(msg)

#     def _pub_heading(self, angle):
#         msg = Float64()
#         msg.data = float(angle)
#         self.pub_heading.publish(msg)

#     def _pub_velocity(self, v):
#         msg = Float64()
#         msg.data = float(v)
#         self.pub_vel.publish(msg)

# def main(args=None):
#     rclpy.init(args=args)
#     node = APFPlannerTrack()
#     try:
#         rclpy.spin(node)
#     except KeyboardInterrupt:
#         pass
#     finally:
#         node.destroy_node()
#         if rclpy.ok():
#             rclpy.shutdown()

# if __name__ == '__main__':
#     main()

"""
APF City Track Planner — Team 12 (Hardware Optimized)
=====================================================
- Path: Clockwise (CW)
- Frame: Hardware-aligned (Initial heading 0 = Start of Left Leg looking 'Up')
- Headings: Cumulative decreasing (0 -> -pi/2 -> -pi -> -1.5pi)
"""

import math
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Point

# ─────────────────────────────────────────────────────────────────────────────
# Track Geometry - Hardware Frame
# ─────────────────────────────────────────────────────────────────────────────
# We assume the car starts at the bottom of the left leg looking "Up".
# Hardware +X = "Up" (The long 3.25m leg)
# Hardware -Y = "Right" (The direction of the first turn)
turn_radius = 0.6  # m (approximate turn radius for cornering)
HW_X_LOW  = -1.7  # Starting X (approx)
HW_X_HIGH = 1.7   # X at the first corner
HW_Y_LEFT = 0.0     # Starting Y (Left leg)
HW_Y_RIGHT = -4.3  # Y of the right leg (Short straight length approx 4.25m)

WAYPOINTS = [
    # (x,          y,           type,      v_straight, v_corner)
    (HW_X_HIGH-turn_radius,   HW_Y_LEFT,   'corner',   0.0,  0.4),   # 0: Start of Left Leg (Top-Left),
    (HW_X_HIGH-turn_radius*(1-math.cos(math.pi/4)),   HW_Y_LEFT - turn_radius*(1-math.sin(math.pi/4)),   'corner',   0.0,  0.4),   # 0: middle of Left Leg (Top-Left)
    (HW_X_HIGH,   HW_Y_LEFT-turn_radius,   'corner',   0.0,  0.4),   # 0: End of Left Leg (Top-Left)
    (HW_X_HIGH,   HW_Y_RIGHT+turn_radius,  'corner',   0.0,  0.4),   # 1: Start of Top-Right
    (HW_X_HIGH-turn_radius*(1-math.cos(math.pi/4)),   HW_Y_RIGHT+turn_radius*(1-math.cos(math.pi/4)),  'corner',   0.0,  0.4),   # 1: Middle ofTop-Right
    (HW_X_HIGH-turn_radius,   HW_Y_RIGHT,  'corner',   0.0,  0.4),   # 1: End of Top-Right
    (HW_X_LOW+turn_radius,    HW_Y_RIGHT,  'corner',   0.0,  0.4),   # 2: Start of Bot-Right
    (HW_X_LOW+turn_radius*(1-math.cos(math.pi/4)),    HW_Y_RIGHT+turn_radius*(1-math.cos(math.pi/4)),  'corner',   0.0,  0.4),   # 2: Middle of Bot-Right
    (HW_X_LOW,    HW_Y_RIGHT+turn_radius,  'corner',   0.0,  0.4),   # 2: End of Bot-Right
    (HW_X_LOW,    HW_Y_LEFT-turn_radius,   'corner',   0.0,  0.4),   # 3: Start of Bot-Left
    (HW_X_LOW+turn_radius*(1-math.cos(math.pi/4)),    HW_Y_LEFT-turn_radius*(1-math.sin(math.pi/4)),  'corner',   0.0,  0.4),   # 3: Middle of Bot-Left
    (HW_X_LOW+turn_radius,    HW_Y_LEFT,   'corner',   0.0,  0.4),   # 3: End of Bot-Left
    (HW_X_HIGH-turn_radius,   HW_Y_LEFT,   'corner',   0.0,  0.4)   # 0: Start of Left Leg (Top-Left),

]

# Headings: Consistently decreasing for Clockwise motion
STRAIGHT_HEADINGS = {
    0:  0.0,                # Moving Up (+X hardware)
    1: -math.pi / 2,        # Moving Right (-Y hardware)
    2: -math.pi / 2,        # Moving Right (-Y hardware)
    3: -math.pi / 2,        # Moving Right (-Y hardware)
    4: -math.pi ,            # Moving Down (-X hardware)
    5: - math.pi,      # Moving Left (+Y hardware)
    6: - math.pi ,    # Moving Left (+Y hardware)
    7: - math.pi * 3/2,            # Moving Up (+X hardware)
    8: -math.pi * 3/2,            # Moving Up (+X hardware)
    9: -math.pi * 3/2,            # Moving Up (+X hardware)
    10: -math.pi * 2,            # Moving Right (-Y hardware)
    11: -math.pi * 2,              # Moving Up (+X hardware)
    12: -math.pi * 2,              # Moving Up (+X hardware)
}

# Distance thresholds
CORNER_REACH_DIST   = 0.4   # m
STRAIGHT_SPEED      = 1.0    # m/s
CORNER_SPEED        = 0.4    # m/s

class track3_planner(Node):

    def __init__(self):
        super().__init__('track3_planner')

        # Publishers
        self.pub_goal    = self.create_publisher(Point,   '/goal_point',       10)
        self.pub_vel     = self.create_publisher(Float64, '/desired_velocity',  10)
        self.pub_heading = self.create_publisher(Float64, '/desired_heading',   10)

        # Subscriber
        self.create_subscription(Odometry, '/odom', self.odom_cb, 10)

        # State
        self.x, self.y, self.speed = 0.0, 0.0, 0.0
        self.wp_idx = 0   
        self.on_straight = False  


        self.timer = self.create_timer(0.1, self.plan_cb)
        self.get_logger().info('Hardware Planner (CW) initialized at Heading 0.')

    def odom_cb(self, msg: Odometry):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        self.speed = msg.twist.twist.linear.x

    def plan_cb(self):
        wx, wy, _, _, _ = WAYPOINTS[self.wp_idx]
        dist = math.hypot(wx - self.x, wy - self.y)

        if not self.on_straight:
            self._publish_corner_mode(wx, wy, dist)
        else:
            self._publish_straight_mode(dist)

    def _publish_corner_mode(self, wx, wy, dist):
        """Targets the corner waypoint with decreasing heading logic."""
        #raw_heading = math.atan2(wy - self.y, wx - self.x)
        
        # Heading Unwrapping logic for Leg 4 (returning to WP 0)
        # Keeps the heading in the -1.5pi neighborhood instead of jumping to +0.5pi
        #heading = raw_heading
        if self.wp_idx == 0 and self.x < 0: # Approaching WP0 from the bottom straight
             if raw_heading > 0:
                 heading = raw_heading - 2 * math.pi
 
        heading = STRAIGHT_HEADINGS[self.wp_idx]
        self._pub_goal(wx, wy)
        self._pub_heading(heading)
        self._pub_velocity(CORNER_SPEED)

        if dist < CORNER_REACH_DIST:
            self.get_logger().info(f'WP {self.wp_idx} reached.')
            self.on_straight = True

    def _publish_straight_mode(self, dist_to_corner):
        """Drives the straight segment using cumulative headings."""
        next_idx = (self.wp_idx + 1) % len(WAYPOINTS)
        nx, ny, _, _, _ = WAYPOINTS[next_idx]

        heading = STRAIGHT_HEADINGS[next_idx]

        self._pub_goal(nx, ny)
        self._pub_heading(heading)
        self._pub_velocity(STRAIGHT_SPEED)

        # Check distance to the next waypoint to trigger the next corner mode
        dist_next = math.hypot(nx - self.x, ny - self.y)
        if (dist_next < CORNER_REACH_DIST):
            self.wp_idx = next_idx
            self.on_straight = False

    def _pub_goal(self, x, y):
        msg = Point()
        msg.x, msg.y = float(x), float(y)
        self.pub_goal.publish(msg)

    def _pub_heading(self, angle):
        msg = Float64()
        msg.data = float(angle)
        self.pub_heading.publish(msg)

    def _pub_velocity(self, v):
        msg = Float64()
        msg.data = float(v)
        self.pub_vel.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = track3_planner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()