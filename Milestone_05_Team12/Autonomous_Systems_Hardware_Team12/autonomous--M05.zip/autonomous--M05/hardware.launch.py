import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node


def generate_launch_description():

    # ── Launch arguments ──────────────────────────────────────────────────
    mode_arg = DeclareLaunchArgument(
        'mode',
        default_value='teleop',
        description='Control mode: teleop or auto'
    )
    mode = LaunchConfiguration('mode')

    velocity_arg = DeclareLaunchArgument(
        'velocity', default_value='1.5',
        description='Velocity for auto mode (m/s)'
    )

    steering_arg = DeclareLaunchArgument(
        'steering', default_value='0.8',
        description='Steering angle for auto mode (-1 to +1)'
    )

    kp_arg = DeclareLaunchArgument(
        'kp', default_value='0.5',
        description='Proportional gain for closed-loop speed control'
    )

    # ── Package paths ─────────────────────────────────────────────────────
    gazebo_pkg   = get_package_share_directory('gazebo_ackermann_steering_vehicle')
    team_pkg     = get_package_share_directory('autonomous_systems_project_team_12')

    vehicle_params_path = os.path.join(gazebo_pkg, 'config', 'parameters.yaml')

    # ── Nodes ─────────────────────────────────────────────────────────────

    # Always running
    vehicle_controller_node = Node(
        package='gazebo_ackermann_steering_vehicle',
        executable='vehicle_controller',
        parameters=[vehicle_params_path],
        output='screen'
    )

    esp_bridge_node = Node(
        package='autonomous_systems_project_team_12',
        executable='esp_bridge',
        output='screen'
    )

    localization_node = Node(
    package='autonomous_systems_project_team_12',
    executable='localization_node',
    output='screen'
    )

    # Teleop mode only (Runs the closed-loop controller with teleop targets)
    teleop_vehicle_controller_node = Node(
        package='autonomous_systems_project_team_12',
        executable='clr_Pcontrol',
        output='screen',
        parameters=[{
            'velocity': 0.0, # Default to 0 for safety before pressing keys
            'steering_angle': 0.0,
            'kp': LaunchConfiguration('kp'),
        }],
        condition=IfCondition(
            PythonExpression(["'", mode, "' == 'teleop'"])
        )
    )

    # Auto mode only (Runs the old open-loop node)
    olr_node = Node(
        package='autonomous_systems_project_team_12',
        executable='olr_node',
        output='screen',
        parameters=[{
            'velocity':       LaunchConfiguration('velocity'),
            'steering_angle': LaunchConfiguration('steering'),
        }],
        condition=IfCondition(
            PythonExpression(["'", mode, "' == 'auto'"])
        )
    )

        # Track 1 mode only (Runs the track 1 planner)
    track1_node = Node(
        package='autonomous_systems_project_team_12',
        executable='track1_node',
        output='screen',
        condition=IfCondition(
            PythonExpression(["'", mode, "' == 'track'"])
        )
    )
    track2_node = Node(
        package='autonomous_systems_project_team_12',
        executable='track2_node',
        output='screen',
        condition=IfCondition(
            PythonExpression(["'", mode, "' == 'track'"])
        )
    )
    track3_node = Node(
        package='autonomous_systems_project_team_12',
        executable='track3_node',
        output='screen',
        condition=IfCondition(
            PythonExpression(["'", mode, "' == 'track3'"])
        )
    )

    speed_control_node = Node(
        package='autonomous_systems_project_team_12',
        executable='speed_control_node',
        output='screen',
        condition=IfCondition(
            PythonExpression(["'", mode, "' == 'track3'"])
        )
    )

    speed_control_node1_2 = Node(
        package='autonomous_systems_project_team_12',
        executable='speed_control_node1_2',
        output='screen',
        condition=IfCondition(
            PythonExpression([
                "'", mode, "' == 'track'" ])
        )
    )

    AckermannEKF = Node(
        package='autonomous_systems_project_team_12',
        executable='AckermannEKF',
        output='screen'
    )
    

    Stanley_Controller = Node(
        package='autonomous_systems_project_team_12',
        executable='Stanley_Controller',
        output='screen',
        condition=IfCondition(
            PythonExpression(["'", mode, "' == 'track3'"])
        )
    )

    Stanley_Controller1_2 = Node(
        package='autonomous_systems_project_team_12',
        executable='Stanley_Controller1_2',
        output='screen',
        condition=IfCondition(
            PythonExpression(["'", mode, "' == 'track'"])
            )
    )
    return LaunchDescription([
        mode_arg,
        velocity_arg,
        steering_arg,
        kp_arg,
        vehicle_controller_node,
        esp_bridge_node,
        #  localization_node,
        # teleop_vehicle_controller_node,
        # olr_node,
        track1_node,
        # track3_node,
        # track2_node,
        # speed_control_node,
        speed_control_node1_2,
        # Stanley_Controller,
        Stanley_Controller1_2,
        AckermannEKF
    ])