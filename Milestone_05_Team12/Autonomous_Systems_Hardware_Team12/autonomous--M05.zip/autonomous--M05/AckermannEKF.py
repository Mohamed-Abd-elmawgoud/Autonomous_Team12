#!/usr/bin/env python3
"""
fused_odom_node.py

Single node: raw sensors → EKF → /odom + TF

Subscribes to:
    /encoder_ticks  (std_msgs/Int64)   — cumulative ticks from ESP
    /imu_heading    (std_msgs/Float32) — yaw from ESP Kalman, DEGREES
    /cmd_steering   (std_msgs/Float64) — steering command from Stanley, radians

Publishes:
    /odom  (nav_msgs/Odometry)         — EKF-filtered pose + velocity
Broadcasts:
    TF: odom → base_link
"""

import math
import numpy as np

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int64, Float32, Float64
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped, Quaternion
from tf2_ros import TransformBroadcaster


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def yaw_to_quaternion(yaw: float) -> Quaternion:
    q = Quaternion()
    q.w = math.cos(yaw / 2.0)
    q.x = 0.0
    q.y = 0.0
    q.z = math.sin(yaw / 2.0)
    return q


# ---------------------------------------------------------------------------
# EKF — Ackermann kinematic model
# State:  [x, y, theta, phi]
# Input:  [Vd, u2]   (Vd = desired speed, u2 = steering rate ≈ 0)
# ---------------------------------------------------------------------------
class AckermannEKF:

    H_POSE = np.array(          # observes [x, y, theta] from encoder+IMU
        [[1, 0, 0, 0],
         [0, 1, 0, 0],
         [0, 0, 1, 0]],
        dtype=float,
    )

    H_STEER = np.array(         # observes [phi] from /cmd_steering
        [[0, 0, 0, 1]],
        dtype=float,
    )

    def __init__(self, L, dt, Q, R_pose, R_steer, x0, P0):
        self.L       = L
        self.dt      = dt
        self.Q       = Q
        self.R_pose  = R_pose
        self.R_steer = R_steer
        self.x_hat   = x0.copy().astype(float)
        self.P       = P0.copy().astype(float)

    # ── State transition ──────────────────────────────────────────────────
    def _f(self, x, u):
        px, py, theta, phi = x
        Vd, u2 = u
        dt, L  = self.dt, self.L
        return np.array([
            px    + dt * Vd * math.cos(theta),
            py    + dt * Vd * math.sin(theta),
            theta + dt * Vd * math.tan(phi) / L,
            phi   + dt * u2,
        ])

    # ── Jacobian ──────────────────────────────────────────────────────────
    def _F_jacobian(self, x_hat, u):
        _, _, theta_hat, phi_hat = x_hat
        Vd, _ = u
        dt, L = self.dt, self.L
        cos_phi = math.cos(phi_hat)
        if abs(cos_phi) < 1e-6:
            cos_phi = 1e-6
        return np.array([
            [1, 0, -dt * Vd * math.sin(theta_hat), 0                            ],
            [0, 1,  dt * Vd * math.cos(theta_hat), 0                            ],
            [0, 0,  1,                              dt * Vd / (L * cos_phi ** 2)],
            [0, 0,  0,                              1                            ],
        ])

    # ── Predict ───────────────────────────────────────────────────────────
    def predict(self, u):
        F          = self._F_jacobian(self.x_hat, u)
        self.x_hat = self._f(self.x_hat, u)
        self.P     = F @ self.P @ F.T + self.Q

    # ── Generic update ────────────────────────────────────────────────────
    def update(self, z, H, R, wrap_index=-1):
        y_innov = z - H @ self.x_hat
        if 0 <= wrap_index < len(y_innov):
            y_innov[wrap_index] = (
                (y_innov[wrap_index] + math.pi) % (2 * math.pi) - math.pi
            )
        S          = H @ self.P @ H.T + R
        K          = self.P @ H.T @ np.linalg.inv(S)
        self.x_hat = self.x_hat + K @ y_innov
        I_KH       = np.eye(4) - K @ H
        self.P     = I_KH @ self.P @ I_KH.T + K @ R @ K.T

    def update_pose(self, x_m, y_m, theta_m):
        self.update(
            np.array([x_m, y_m, theta_m]),
            self.H_POSE, self.R_pose,
            wrap_index=2,
        )

    def update_steering(self, phi_m):
        self.update(
            np.array([phi_m]),
            self.H_STEER, self.R_steer,
        )

    @property
    def state(self):
        return self.x_hat.copy()

    @property
    def covariance(self):
        return self.P.copy()


# ---------------------------------------------------------------------------
# ROS2 Node
# ---------------------------------------------------------------------------
class FusedOdomNode(Node):

    def __init__(self):
        super().__init__('fused_odom_node')

        # ── Parameters ────────────────────────────────────────────────────
        self.declare_parameter('wheelbase_L',        0.255)
        self.declare_parameter('wheel_diameter_m',   0.065)
        self.declare_parameter('ticks_per_motor_rev', 11)
        self.declare_parameter('gear_ratio',          102)
        self.declare_parameter('desired_speed_Vd',    0.5)
        self.declare_parameter('dt',                  0.05)
        self.declare_parameter('Q_diag',    [0.01, 0.01, 0.005, 0.005])
        self.declare_parameter('R_pose_diag', [0.05, 0.05, 0.02])
        self.declare_parameter('R_steer_diag', [0.02])
        self.declare_parameter('odom_frame',   'odom')
        self.declare_parameter('base_frame',   'base_link')

        L           = self.get_parameter('wheelbase_L').value
        wheel_d     = self.get_parameter('wheel_diameter_m').value
        tpm         = self.get_parameter('ticks_per_motor_rev').value
        gr          = self.get_parameter('gear_ratio').value
        self.Vd     = self.get_parameter('desired_speed_Vd').value
        dt          = self.get_parameter('dt').value
        Q_d         = self.get_parameter('Q_diag').value
        R_pose_d    = self.get_parameter('R_pose_diag').value
        R_steer_d   = self.get_parameter('R_steer_diag').value
        self._odom_frame = self.get_parameter('odom_frame').value
        self._base_frame = self.get_parameter('base_frame').value

        ticks_per_rev    = tpm * gr
        self._mpt        = (math.pi * wheel_d) / ticks_per_rev  # metres/tick

        # ── EKF ───────────────────────────────────────────────────────────
        self.ekf = AckermannEKF(
            L=L,
            dt=dt,
            Q=np.diag(Q_d),
            R_pose=np.diag(R_pose_d),
            R_steer=np.diag(R_steer_d),
            x0=np.zeros(4),
            P0=np.eye(4) * 1.0,
        )

        # ── Dead-reckoning accumulators (pre-EKF position estimate) ───────
        # Used to build the pose measurement fed into EKF.update_pose()
        self._dr_x     = 0.0
        self._dr_y     = 0.0

        # ── Raw sensor state ──────────────────────────────────────────────
        self._imu_yaw      = 0.0          # radians, from /imu_heading
        self._last_ticks   = None         # seeded on first tick message
        self._last_yaw     = 0.0
        self._last_time    = self.get_clock().now()
        self._latest_phi   = None         # from /cmd_steering
        self._initialized  = False

        # ── TF broadcaster ────────────────────────────────────────────────
        self.tf_broadcaster = TransformBroadcaster(self)

        # ── Publishers ────────────────────────────────────────────────────
        self.pub_odom = self.create_publisher(Odometry, '/odom', 10)

        # ── Subscribers ───────────────────────────────────────────────────
        self.create_subscription(
            Float32, '/imu_heading',
            self._imu_cb, 10,
        )
        self.create_subscription(
            Int64, '/encoder_ticks',
            self._ticks_cb, 10,
        )
        self.create_subscription(
            Float64, '/steering_angle',
            self._steering_cb, 10,
        )

        self.get_logger().info(
            f'FusedOdomNode ready  |  L={L} m  |  '
            f'{ticks_per_rev} ticks/rev  |  {self._mpt*1000:.4f} mm/tick'
        )

    # ======================================================================
    # /imu_heading — degrees → radians, just cache it
    # ======================================================================
    def _imu_cb(self, msg: Float32):
        self._imu_yaw = math.radians(float(msg.data))

    # ======================================================================
    # /cmd_steering — cache phi, apply EKF update immediately if running
    # ======================================================================
    def _steering_cb(self, msg: Float64):
        self._latest_phi = float(msg.data)
        if self._initialized:
            self.ekf.update_steering(self._latest_phi)

    # ======================================================================
    # /encoder_ticks — main loop: dead-reckon → EKF predict+update → publish
    # ======================================================================
    def _ticks_cb(self, msg: Int64):
        current_time  = self.get_clock().now()
        current_ticks = int(msg.data)

        # ── Seed on first message ─────────────────────────────────────────
        if self._last_ticks is None:
            self._last_ticks  = current_ticks
            self._last_time   = current_time
            self._last_yaw    = self._imu_yaw
            return

        # ── dt ────────────────────────────────────────────────────────────
        dt = (current_time - self._last_time).nanoseconds / 1e9
        if dt <= 0.0:
            return

        # ── Displacement from encoder ─────────────────────────────────────
        d_ticks  = current_ticks - self._last_ticks
        ds       = d_ticks * self._mpt
        v_linear = ds / dt

        # ── Heading from IMU (already radians) ────────────────────────────
        theta = self._imu_yaw

        # ── Angular velocity ──────────────────────────────────────────────
        d_yaw    = theta - self._last_yaw
        d_yaw    = math.atan2(math.sin(d_yaw), math.cos(d_yaw))
        v_angular = d_yaw / dt

        # ── Dead-reckon x, y as pose measurement for EKF ─────────────────
        self._dr_x += ds * math.cos(theta)
        self._dr_y += ds * math.sin(theta)

        # ── EKF predict ───────────────────────────────────────────────────
        self.ekf.dt = dt
        u = np.array([v_linear, 0.0])   # Vd = current speed, u2 = 0
        self.ekf.predict(u)

        # ── EKF update: pose from dead-reckoning + IMU ────────────────────
        self.ekf.update_pose(self._dr_x, self._dr_y, theta)

        # ── EKF update: steering if available ────────────────────────────
        if self._latest_phi is not None:
            self.ekf.update_steering(self._latest_phi)

        # ── Mark initialized ─────────────────────────────────────────────
        if not self._initialized:
            self._initialized = True
            self.get_logger().info(
                f'EKF initialized  |  '
                f'x={self._dr_x:.3f}  y={self._dr_y:.3f}  '
                f'θ={math.degrees(theta):.1f}°'
            )

        # ── Publish ───────────────────────────────────────────────────────
        stamp = current_time.to_msg()
        self._publish_odom(stamp, v_linear, v_angular)
        self._publish_tf(stamp)

        # ── Save state ────────────────────────────────────────────────────
        self._last_ticks = current_ticks
        self._last_time  = current_time
        self._last_yaw   = theta

    # ======================================================================
    # Publish /odom
    # ======================================================================
    def _publish_odom(self, stamp, v_lin, v_ang):
        state = self.ekf.state    # [x, y, theta, phi]
        cov   = self.ekf.covariance
        # Print the filtered states to the terminal
        self.get_logger().info(
            f"Filtered State -> X: {state[0]:.2f}, Y: {state[1]:.2f}, "
            f"Yaw: {math.degrees(state[2]):.2f}°, Steer: {math.degrees(state[3]):.2f}°", throttle_duration_sec=0.5
        )
        msg = Odometry()
        msg.header.stamp    = stamp
        msg.header.frame_id = self._odom_frame
        msg.child_frame_id  = self._base_frame

        msg.pose.pose.position.x  = state[0]
        msg.pose.pose.position.y  = state[1]
        msg.pose.pose.position.z  = 0.0
        msg.pose.pose.orientation = yaw_to_quaternion(state[2])

        msg.twist.twist.linear.x  = v_lin
        msg.twist.twist.linear.y  = 0.0
        msg.twist.twist.linear.z  = 0.0
        msg.twist.twist.angular.x = 0.0
        msg.twist.twist.angular.y = 0.0
        msg.twist.twist.angular.z = v_ang

        # ── 6×6 pose covariance from EKF ─────────────────────────────────
        P6 = np.zeros((6, 6))
        p6_map = [
            (0, 0), (0, 1), (1, 0), (1, 1),
            (0, 5), (5, 0), (1, 5), (5, 1),
            (5, 5),
        ]
        ekf_map = [
            (0, 0), (0, 1), (1, 0), (1, 1),
            (0, 2), (2, 0), (1, 2), (2, 1),
            (2, 2),
        ]
        for (r6, c6), (re, ce) in zip(p6_map, ekf_map):
            P6[r6, c6] = cov[re, ce]
        msg.pose.covariance = P6.flatten().tolist()

        self.pub_odom.publish(msg)

    # ======================================================================
    # Broadcast TF
    # ======================================================================
    def _publish_tf(self, stamp):
        state = self.ekf.state
        t = TransformStamped()
        t.header.stamp    = stamp
        t.header.frame_id = self._odom_frame
        t.child_frame_id  = self._base_frame

        t.transform.translation.x = state[0]
        t.transform.translation.y = state[1]
        t.transform.translation.z = 0.0

        t.transform.rotation = yaw_to_quaternion(state[2])

        self.tf_broadcaster.sendTransform(t)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main(args=None):
    rclpy.init(args=args)
    node = FusedOdomNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()