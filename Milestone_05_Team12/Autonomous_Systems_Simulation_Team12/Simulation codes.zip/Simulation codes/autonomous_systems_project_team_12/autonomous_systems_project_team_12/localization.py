#!/usr/bin/env python3
"""
Autonomous_Systems_MS_5_Localization_Team_12.py
================================================
Localization Node — Milestone 5
GUC | MCTR 1002 — Autonomous Systems | Spring 2026

Responsibilities
----------------
1. Subscribe to /odom (nav_msgs/Odometry) — Gazebo ground-truth states.
2. Extract ideal states [x, y, theta] and inputs [v, omega].
3. Add white Gaussian noise to all states and inputs to mimic real sensors.
4. Publish the noisy measurements to the Kalman Filter node.

Topic I/O
---------
Subscriptions:
    /odom               (nav_msgs/Odometry)  — ground-truth from Gazebo

Publications:
    /noisy_odom         (nav_msgs/Odometry)  — noisy x, y, theta, v, omega
    /noisy_velocity     (std_msgs/Float64)   — noisy linear velocity  [v_car]
    /noisy_omega        (std_msgs/Float64)   — noisy angular velocity [omega_car]

Parameters (overridable from launch file)
-----------------------------------------
    std_x      : std-dev of x position noise       (default 0.02  m)
    std_y      : std-dev of y position noise       (default 0.02  m)
    std_theta  : std-dev of heading noise          (default 0.01  rad)
    std_v      : std-dev of linear velocity noise  (default 0.05  m/s)
    std_omega  : std-dev of angular velocity noise (default 0.02  rad/s)
"""

import math
import numpy as np

import rclpy
from rclpy.node import Node

from nav_msgs.msg import Odometry
from std_msgs.msg import Float64


def quat_to_yaw(q) -> float:
    """Convert a ROS quaternion to a yaw angle [rad]."""
    siny = 2.0 * (q.w * q.z + q.x * q.y)
    cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny, cosy)


def yaw_to_quat(yaw: float):
    """Return (qx, qy, qz, qw) for a pure-yaw rotation."""
    return 0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0)


class LocalizationNode(Node):
    """
    Mimics real sensor readings by corrupting Gazebo ground-truth odometry
    with white Gaussian noise before passing it to the Kalman Filter node.
    """

    def __init__(self):
        super().__init__('Autonomous_Systems_MS_5_Localization_Team_12')

        # ── ROS 2 parameters (noise std-devs, set from launch file) ──────
        self.declare_parameter('std_x',     0.05)   # m
        self.declare_parameter('std_y',     0.05)   # m
        self.declare_parameter('std_theta', 0.05)   # rad
        self.declare_parameter('std_v',     0.05)   # m/s
        self.declare_parameter('std_omega', 0.02)   # rad/s

        self.std_x     = self.get_parameter('std_x').value
        self.std_y     = self.get_parameter('std_y').value
        self.std_theta = self.get_parameter('std_theta').value
        self.std_v     = self.get_parameter('std_v').value
        self.std_omega = self.get_parameter('std_omega').value

        self.get_logger().info(
            f'[Localization] Noise std-devs → '
            f'x={self.std_x} m | y={self.std_y} m | θ={self.std_theta} rad | '
            f'v={self.std_v} m/s | ω={self.std_omega} rad/s'
        )

        # ── Subscriber ───────────────────────────────────────────────────
        self.odom_sub = self.create_subscription(
            Odometry,
            '/odom',
            self._odom_callback,
            10
        )

        # ── Publishers ───────────────────────────────────────────────────
        # Primary noisy odometry → Kalman Filter (same Odometry type as /odom)
        self.noisy_odom_pub = self.create_publisher(
            Odometry,
            '/noisy_odom',
            10
        )

        # Separate Float64 topics for v and omega (KF prediction step inputs)
        self.noisy_v_pub     = self.create_publisher(Float64, '/noisy_velocity', 10)
        self.noisy_omega_pub = self.create_publisher(Float64, '/noisy_omega',    10)

        self.get_logger().info('[Localization] Waiting for /odom …')

    # ------------------------------------------------------------------ #
    #  Callback                                                            #
    # ------------------------------------------------------------------ #
    def _odom_callback(self, msg: Odometry):
        """
        Receives ground-truth odometry, adds AWGN to every state and input,
        then re-publishes as noisy Odometry (same message structure as /odom).
        """
        # ── 1. Extract ideal (ground-truth) values ───────────────────────
        x_ideal     = msg.pose.pose.position.x
        y_ideal     = msg.pose.pose.position.y
        theta_ideal = quat_to_yaw(msg.pose.pose.orientation)

        v_ideal     = msg.twist.twist.linear.x
        omega_ideal = msg.twist.twist.angular.z

        # ── 2. Add white Gaussian noise ──────────────────────────────────
        #       Measurement noise covariance R  → applied to states
        x_noisy     = x_ideal     + np.random.normal(0.0, self.std_x)
        y_noisy     = y_ideal     + np.random.normal(0.0, self.std_y)
        theta_noisy = theta_ideal + np.random.normal(0.0, self.std_theta)

        #       Process noise covariance Q → applied to inputs
        v_noisy     = v_ideal     + np.random.normal(0.0, self.std_v)
        omega_noisy = omega_ideal + np.random.normal(0.0, self.std_omega)

        # ── 3. Pack noisy values into an Odometry message ────────────────
        #       Identical type to /odom — no new message types needed
        noisy_msg = Odometry()
        noisy_msg.header.stamp    = self.get_clock().now().to_msg()
        noisy_msg.header.frame_id = msg.header.frame_id   # 'odom'
        noisy_msg.child_frame_id  = msg.child_frame_id    # 'base_link'

        # Noisy position
        noisy_msg.pose.pose.position.x = x_noisy
        noisy_msg.pose.pose.position.y = y_noisy
        noisy_msg.pose.pose.position.z = 0.0

        # Convert noisy yaw back to a quaternion
        qx, qy, qz, qw = yaw_to_quat(theta_noisy)
        noisy_msg.pose.pose.orientation.x = qx
        noisy_msg.pose.pose.orientation.y = qy
        noisy_msg.pose.pose.orientation.z = qz
        noisy_msg.pose.pose.orientation.w = qw

        # Noisy velocities in the twist field
        noisy_msg.twist.twist.linear.x  = v_noisy
        noisy_msg.twist.twist.angular.z = omega_noisy

        self.noisy_odom_pub.publish(noisy_msg)

        # ── 4. Also publish v and omega as Float64 for KF prediction ─────
        v_msg      = Float64()
        v_msg.data = v_noisy
        self.noisy_v_pub.publish(v_msg)

        omega_msg      = Float64()
        omega_msg.data = omega_noisy
        self.noisy_omega_pub.publish(omega_msg)

        # ── 5. Debug log ─────────────────────────────────────────────────
        self.get_logger().debug(
            f'[Localization]\n'
            f'  Ideal → x={x_ideal:.3f}  y={y_ideal:.3f}  '
            f'θ={math.degrees(theta_ideal):.2f}°  v={v_ideal:.3f}\n'
            f'  Noisy → x={x_noisy:.3f}  y={y_noisy:.3f}  '
            f'θ={math.degrees(theta_noisy):.2f}°  v={v_noisy:.3f}'
        )


# ======================================================================== #
#  Entry point                                                               #
# ======================================================================== #
def main(args=None):
    rclpy.init(args=args)
    node = LocalizationNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()