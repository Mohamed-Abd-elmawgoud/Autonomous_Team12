#!/usr/bin/env python3
"""
Autonomous_Systems_MS_5_KalmanFilter_Team_12.py
================================================
Kalman Filter Node — Milestone 5
GUC | MCTR 1002 — Autonomous Systems | Spring 2026

Kinematic Model (Unicycle / Differential-Drive):
------------------------------------------------
State vector : X = [x, y, θ]ᵀ
Input vector : U = [v, ω]ᵀ

Discrete Euler prediction (step dt):
    x(k+1) = x(k) + v · cos θ(k) · dt
    y(k+1) = y(k) + v · sin θ(k) · dt
    θ(k+1) = θ(k) + ω · dt

Linearised Jacobian F (3×3):
    F = | 1   0   -v·sin θ·dt |
        | 0   1    v·cos θ·dt |
        | 0   0    1           |

Measurement model:  H = I (3×3)  — we observe x, y, θ directly
"""

import math
import numpy as np

import rclpy
from rclpy.node import Node

from nav_msgs.msg import Odometry
from std_msgs.msg import Float64


def yaw_from_quat(q) -> float:
    siny = 2.0 * (q.w * q.z + q.x * q.y)
    cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny, cosy)


class KalmanFilterNode(Node):

    def __init__(self):
        super().__init__('Autonomous_Systems_MS_5_KalmanFilter_Team_12')

        # ── Parameters ───────────────────────────────────────────────────
        self.declare_parameter('dt',         0.05)
        self.declare_parameter('std_x',      0.05)
        self.declare_parameter('std_y',      0.05)
        self.declare_parameter('std_theta',  0.05)
        self.declare_parameter('std_qx',     0.01)
        self.declare_parameter('std_qy',     0.01)
        self.declare_parameter('std_qtheta', 0.005)

        self.dt        = self.get_parameter('dt').value
        std_x          = self.get_parameter('std_x').value
        std_y          = self.get_parameter('std_y').value
        std_theta      = self.get_parameter('std_theta').value
        std_qx         = self.get_parameter('std_qx').value
        std_qy         = self.get_parameter('std_qy').value
        std_qtheta     = self.get_parameter('std_qtheta').value

        # ── KF Matrices ──────────────────────────────────────────────────
        self.R = np.diag([std_x**2,  std_y**2,  std_theta**2])
        self.Q = np.diag([std_qx**2, std_qy**2, std_qtheta**2])
        self.H = np.eye(3)   # full-state observation

        # ── State & Covariance ────────────────────────────────────────────
        self.X_hat = np.zeros((3, 1))
        self.P     = np.eye(3) * 1.0

        # ── Initialisation guard ──────────────────────────────────────────
        # Do NOT publish or predict until the first real measurement arrives.
        # Without this the KF floods /filtered_odom with (0,0,0) at 20 Hz
        # before the car moves, which breaks every downstream controller.
        self.initialized = False

        # ── Latest inputs ─────────────────────────────────────────────────
        self.v     = 0.0
        self.omega = 0.0

        # ── Measurement buffer ────────────────────────────────────────────
        self.new_measurement = False
        self.z = np.zeros((3, 1))

        # ── Subscribers ──────────────────────────────────────────────────
        self.create_subscription(
            Odometry, '/noisy_odom',
            self._meas_callback, 10)

        self.create_subscription(
            Float64, '/noisy_velocity',
            self._v_callback, 10)

        self.create_subscription(
            Float64, '/noisy_omega',
            self._omega_callback, 10)

        # ── Publishers ───────────────────────────────────────────────────
        self.pub_odom  = self.create_publisher(Odometry, '/filtered_odom',  10)
        self.pub_x     = self.create_publisher(Float64,  '/filtered_x',     10)
        self.pub_y     = self.create_publisher(Float64,  '/filtered_y',     10)
        self.pub_theta = self.create_publisher(Float64,  '/filtered_theta',  10)

        # ── KF timer ─────────────────────────────────────────────────────
        self.timer = self.create_timer(self.dt, self._kf_step)

        self.get_logger().info(
            f'[KalmanFilter — Unicycle 3-state] Ready\n'
            f'  dt={self.dt} s\n'
            f'  R=diag({std_x**2:.4f}, {std_y**2:.4f}, {std_theta**2:.4f})\n'
            f'  Q=diag({std_qx**2:.4f}, {std_qy**2:.4f}, {std_qtheta**2:.4f})\n'
            f'  Waiting for first /noisy_odom measurement before publishing...'
        )

    # ------------------------------------------------------------------ #
    #  Subscriber Callbacks                                                #
    # ------------------------------------------------------------------ #

    def _meas_callback(self, msg: Odometry):
        """Unpack noisy Odometry into z = [x, y, θ]ᵀ."""
        theta = yaw_from_quat(msg.pose.pose.orientation)
        self.z = np.array([[msg.pose.pose.position.x],
                           [msg.pose.pose.position.y],
                           [theta]])

        # Seed the state estimate from the very first real measurement
        # instead of starting at (0, 0, 0) which poisons all controllers
        if not self.initialized:
            self.X_hat      = self.z.copy()
            self.initialized = True
            self.get_logger().info(
                f'[KF] Initialized from first measurement → '
                f'x={float(self.z[0]):.3f}  '
                f'y={float(self.z[1]):.3f}  '
                f'θ={math.degrees(float(self.z[2])):.2f}°'
            )

        self.new_measurement = True

    def _v_callback(self, msg: Float64):
        self.v = msg.data

    def _omega_callback(self, msg: Float64):
        self.omega = msg.data

    # ------------------------------------------------------------------ #
    #  Kalman Filter Step                                                  #
    # ------------------------------------------------------------------ #

    def _kf_step(self):
        # Block until seeded with a real measurement
        if not self.initialized:
            return

        dt    = self.dt
        v     = self.v
        omega = self.omega

        x  = float(self.X_hat[0])
        y  = float(self.X_hat[1])
        th = float(self.X_hat[2])

        # ── PREDICTION ───────────────────────────────────────────────────
        x_pred  = x  + v * math.cos(th) * dt
        y_pred  = y  + v * math.sin(th) * dt
        th_pred = th + omega * dt

        X_pred = np.array([[x_pred], [y_pred], [th_pred]])

        F = np.array([
            [1.0,  0.0,  -v * math.sin(th) * dt],
            [0.0,  1.0,   v * math.cos(th) * dt],
            [0.0,  0.0,   1.0                   ],
        ])

        P_pred = F @ self.P @ F.T + self.Q

        # ── UPDATE ───────────────────────────────────────────────────────
        if self.new_measurement:
            # Innovation  (H = I so this simplifies cleanly)
            y_inn = self.z - X_pred

            # Wrap heading innovation to [-π, π]
            y_inn[2, 0] = math.atan2(
                math.sin(y_inn[2, 0]),
                math.cos(y_inn[2, 0])
            )

            # S = P_pred + R  (since H = I)
            S = P_pred + self.R

            # K = P_pred · S⁻¹  (since H = I)
            K = P_pred @ np.linalg.inv(S)

            # Updated state
            self.X_hat = X_pred + K @ y_inn

            # Joseph form for numerical stability
            I_KH   = np.eye(3) - K @ self.H
            self.P = I_KH @ P_pred @ I_KH.T + K @ self.R @ K.T

            self.new_measurement = False
        else:
            self.X_hat = X_pred
            self.P     = P_pred

        self._publish()

    # ------------------------------------------------------------------ #
    #  Publish filtered states                                             #
    # ------------------------------------------------------------------ #

    def _publish(self):
        x_f  = float(self.X_hat[0])
        y_f  = float(self.X_hat[1])
        th_f = float(self.X_hat[2])

        # ── Filtered Odometry ─────────────────────────────────────────────
        odom = Odometry()
        odom.header.stamp    = self.get_clock().now().to_msg()
        odom.header.frame_id = 'odom'
        odom.child_frame_id  = 'base_link'

        odom.pose.pose.position.x = x_f
        odom.pose.pose.position.y = y_f
        odom.pose.pose.position.z = 0.0

        odom.pose.pose.orientation.w = math.cos(th_f / 2.0)
        odom.pose.pose.orientation.x = 0.0
        odom.pose.pose.orientation.y = 0.0
        odom.pose.pose.orientation.z = math.sin(th_f / 2.0)

        odom.twist.twist.linear.x  = self.v
        odom.twist.twist.angular.z = self.omega

        self.pub_odom.publish(odom)

        # ── Float64 per-state (rqt_plot) ──────────────────────────────────
        msg_x = Float64();  msg_x.data  = x_f;   self.pub_x.publish(msg_x)
        msg_y = Float64();  msg_y.data  = y_f;   self.pub_y.publish(msg_y)
        msg_t = Float64();  msg_t.data  = th_f;  self.pub_theta.publish(msg_t)

        self.get_logger().debug(
            f'[KF] x={x_f:.3f}  y={y_f:.3f}  θ={math.degrees(th_f):.2f}°'
        )


# ======================================================================== #
#  Entry point                                                               #
# ======================================================================== #

def main(args=None):
    rclpy.init(args=args)
    node = KalmanFilterNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()