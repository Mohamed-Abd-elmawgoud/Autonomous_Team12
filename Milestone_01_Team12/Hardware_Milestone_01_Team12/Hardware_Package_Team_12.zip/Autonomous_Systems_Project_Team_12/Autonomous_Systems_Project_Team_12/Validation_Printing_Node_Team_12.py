#!/usr/bin/env python3
import rclpy
from rclpy.node import Node

class HelloWorldNode(Node):
    def __init__(self):
        # Initialize the node with the name 'hello_world_node'
        super().__init__('Validation_Printing_Node_Team_12')
        
        # Print to the console on separate lines
        self.get_logger().info('Hello from Pi!')
        self.get_logger().info('We are Team 12 :)')

def main(args=None):
    # Initialize the ROS 2 communication
    rclpy.init(args=args)
    
    # Create the node instance
    node = HelloWorldNode()
    
    # Keep the node running (even though it just prints once, this is good practice)
    # If you want it to exit immediately after printing, you can remove rclpy.spin(node)
    rclpy.spin(node)
    
    # Clean up and shutdown
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()